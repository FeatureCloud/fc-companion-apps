import numpy as np
import pandas as pd

from ..engine.app import AppState, LogLevel
import jsonpickle
import jsonpickle.ext.numpy as jsonpickle_numpy
import jsonpickle.ext.pandas as jsonpickle_pd
import json
from time import sleep

jsonpickle_numpy.register_handlers()
jsonpickle_pd.register_handlers()

requirements = ['pandas', 'numpy']


class State(AppState):
    # def encode(self, data):
    #     """ Encode the data regarding `smpc_used` flag.
    #     Parameters
    #     ----------
    #     data:  list
    #
    #     Returns
    #     -------
    #     str: encoded data
    #     """
    #     self.log_data(data, "Raw")
    #     if self.app.internal['smpc_used']:
    #         encoded_data = js_serializer.encode(data)
    #     else:
    #         encoded_data = jsonpickle.encode(data)
    #
    #     self.log_debug(f"Length: {len(data)}", "Encoded_DATA")
    #     return encoded_data

    # def decode(self, data):
    #     """ decodes the data regarding `smpc_used` flag.
    #     Parameters
    #     ----------
    #     data: str
    #         encoded data
    #
    #     Returns
    #     -------
    #     list: list of decoded data
    #     """
    #     self.log_debug(f"Length: {len(data)}", "Encoded_DATA")
    #     if self.app.internal['smpc_used']:
    #         decoded_data = js_serializer.decode(data[0])
    #     if isinstance(data, tuple):
    #         if len(data) == 2:
    #             decoded_data = jsonpickle.decode(data[0])
    #         else:
    #             self.log_debug(f"Arrived data is 'tuple' but without exactly two elements(length: {len(data)})",
    #                            ValueError)
    #     self.log_data(decoded_data, "Decoded")
    #     return decoded_data

    def log_data(self, data, title):
        """ logs the data based on its type, length, and value

        Parameters
        ----------
        data: str
        title: str
        """
        self.log_debug(f"{title} Data:\n"
                       f"\tType: {type(data)}\n"
                       f"\tlength: {len(data)}", "DATA")
        for i, d in enumerate(data):
            if hasattr(d, "__len__") and len(d) > 1:
                self.log_debug(f"\t{i}: Length= {len(d)}", "DATA")
            else:
                self.log_debug(f"\t{i}: Data= {d}", "DATA")

    # def is_clients_data_arrived(self):
    #     """ Regarding the expected data size that should be communicated between clients
    #         it determines all clients data are arrived or not.
    #         Returns
    #         -------
    #         bool: True if all clients data arrived
    #     """
    #     if not self.app.coordinator:
    #         self.log_debug("is_clients_data_arrived() Method should only be called by the coordinator", AssertionError)
    #     if self.app.internal['smpc_used']:
    #         return len(self.app.data_incoming) == 1
    #     return len(self.app.data_incoming) == len(self.app.clients)

    def get_clients_data(self):
        """ returns a generator that yields back data splits.
            When SMPC is not used, it yields data splits for each client
            It should be called only by tyhe coordinator

        Returns
        -------
        generator:
        """
        if not self.coordinator:
            self.log_debug("'get_clients_data()' method is exclusive for the coordinator", AssertionError)
        self.log_clients_data()
        if self.app.internal['smpc_used']:
            data = self.decode(self.app.data_incoming[0])
            self.log_debug(data, "Decoded Aggregated")
            self.app.data_incoming = []
            for i, split in enumerate(self.app.internal['splits']):
                self.log_debug(f'Get {split}', 'SPLIT')
                yield data[i], split
            self.disable_smpc()
        else:
            data = [self.decode(client_data) for client_data in self.app.data_incoming]
            self.app.data_incoming = []
            for i, split in enumerate(self.app.internal['splits']):
                self.log_debug(f'Get {split}', 'SPLIT')
                clients_data = []
                for client in data:
                    clients_data.append(client[i])
                yield clients_data, split

    def log_clients_data(self, clients_data):
        """ Logs the gathered data by the coordinator regarding the SMPC module and data type

        Returns
        -------

        """
        self.log_debug("clients' data arrived", 'RECEIVE')
        if self.app.internal['smpc_used']:
            msg = "Received data is aggregated(i.e., SMPC was used by clients)"
        else:
            msg = "Received data is NOT aggregated(i.e., SMPC was NOT used by clients)"
        self.log_debug(msg, "DATA")
        self.log_debug(f"Number of clients: {len(clients_data)}", "DATA")
        self.log_debug("Recieved data from clients: Client_ID: type, length", "DATA")
        for client_data in clients_data:
            self.log_debug(f"\t{client_data[1]}: {type(client_data[0])},"
                           f" {len(client_data[0]) if hasattr(client_data[0], '__len__') else 1}",
                           "DATA")

    # def is_received_data_aggregated(self):
    #     """ based on usage of SMPC, data can be aggregated
    #
    #     Returns
    #     -------
    #     bool: True if aggregated
    #     """
    #     return self.app.internal["smpc_used"]

    def enable_smpc(self):
        """ Set `smpc_used` flag as True, so the next state beware that the results are aggregated

        """
        self.app.internal['smpc_used'] = True

    def disable_smpc(self):
        """ Once SMPC should not be used, sets the SMPC flag as `False`.

        """
        self.app.internal['smpc_used'] = False

    def get_data_from_coordinator(self, sleep_time=1):
        """ Awaits for receiving the data from coordinator, once it recieves
            yields back the each data split at a time
        Parameters
        ----------
        sleep_time: int
            the time that thread should sleep before checking the data arrival again.

        Returns
        -------
        list: data split received from the coordinator
        """
        while True:
            if len(self.app.data_incoming) > 0:
                self.log_debug(f'Received Data from Coordinator', 'RECEIVED')
                self.log_data(self.app.data_incoming[0], "RECEIVED")
                decoded_incoming_data = self.decode(self.app.data_incoming[0])
                self.app.data_incoming = []
                splits = {split: decoded_incoming_data[i]
                          for i, split in enumerate(self.app.internal['splits'])
                          }
                for k, v in splits.items():
                    self.log_debug(f'Get {k}', 'SPLIT')
                    yield v, k
                break
            sleep(sleep_time)

    def send_data_to_coordinator(self, data, send_to_self=True, use_smpc=False):
        """ Serializes the data, and sends it to coordinator regarding the `use_smpc` flag

        Parameters
        ----------
        data: list
        send_to_self: bool
        use_smpc: bool
        """
        self.log_send_data(data)
        # it is necessary to set on "smpc_used" once you want to delegate the right to use SMPC or not to the end users
        #        And also do not want to apply SMPC on all communications
        if use_smpc:
            self.enable_smpc()
        encoded_data = self.encode(data)
        super(State, self).send_data_to_coordinator(encoded_data, send_to_self=self.app.coordinator,
                                                    use_smpc=use_smpc)

    def send_data_to_participant(self, data, destination):
        """ It can be called by any FeatureCloud clients regardless of roles,
            which takes the destination client id as `destination`.
            it automatically handles the serialization.

        Parameters
        ----------
        data: list
        destination: str
            target client's ID
        """
        self.log_data(data, title="SEND")
        encoded_data = self.encode(data)
        super(State, self).send_data_to_participant(data=encoded_data, destination=destination)

    def log_send_data(self, data):
        """ Logs data in terms of legth, type, and value

        Parameters
        ----------
        data: list
        """
        self.log_debug(f"Sending data to coordinator", "SEND")
        self.log_debug(f"Type: {type(data)}\n"
                       f"length: {len(data)}", "DATA")
        for i, d in enumerate(data[:3]):
            if hasattr(d, '__len__'):
                self.log_debug(f"\t{i} >>> Length: {len(d)}", "DATA")
            else:
                self.log_debug(f"\t{i} >>> Data: {d}", "DATA")

    def broadcast_data(self, data, send_to_self=True):
        """ should be only called by the coordinator and sends the for all clients.
            it automatically handles data serialization.
        Parameters
        ----------
        data: list
        send_to_self: bool

        """
        encoded_data = self.encode(data)
        super(State, self).broadcast_data(encoded_data, send_to_self)

    def log_debug(self, msg, state=None):
        """ Gets string message and a state which can be interpreted later in FeatureCloud front-end.
            The message is useful for both debugging and reporting.

        Parameters
        ----------
        msg: str
        state: str or Error

        """
        errors = [NotImplementedError, NotADirectoryError, NotImplemented, RuntimeError, FileNotFoundError,
                  ModuleNotFoundError, AssertionError, AttributeError]
        if state in errors:
            self.app.log(msg, LogLevel.ERROR.value)
            raise state(msg)
        self.app.log(msg, LogLevel.DEBUG)


class JsonSerializer:
    """
    A serilizer to automatically convert all NumPy arrays, Panda DataFrames, and Pandas Series
    in a nested data structure into lists. All list, tuples, and dictionaries in the submitted data
    will remain untouched
    """

    def __init__(self):
        self.encoder = {pd.DataFrame: pd.DataFrame.to_numpy,
                        pd.core.series.Series: pd.Series.tolist,
                        np.ndarray: self.encode_numpy,
                        dict: self.encode_dict,
                        list: self.encode_list}

    def encode(self, data):
        return json.dumps(self.prepare(data))

    def prepare(self, data):
        if type(data) in self.encoder:
            return self.encoder[type(data)](data)
        return data

    def encode_list(self, data):
        l = []
        for item in data:
            l.append(self.prepare(item))
        return l

    def encode_dict(self, data):
        return {k: self.prepare(v) for k, v in data.items()}

    def encode_numpy(self, data):
        l = []
        for item in data.to_list():
            l.append(self.prepare(item))
        return l

    def decode(self, data):
        return json.loads(data)


js_serializer = JsonSerializer()
