from FeatureCloud.CustomStates import ConfigState
from FeatureCloud.engine.app import app_state, Role, AppState, LogLevel
from FeatureCloud.engine.app import State as op_state
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold, KFold
import os

name = 'fc_cross_validation'

default_config = {
    name: {
        'local_dataset': {
            'data': 'data.csv',
            'target_value': 'label',
            'sep': ','
        },
        'n_splits': 10,
        'shuffle': True,
        'stratify': False,
        'random_state': None,
        'split_dir': 'data',
        'result': {
            'train': 'train.csv',
            'test': 'test.csv'
        }
    }
}

requirements = ['pandas', 'numpy', 'sklearn']


@app_state(name='initial', role=Role.BOTH, app_name=name)
class LoadAndSplit(ConfigState.State):

    def register(self):
        self.register_transition('WriteResults', Role.BOTH)

    def run(self):
        self.lazy_init()
        self.read_config()
        self.finalize_config()
        self.app.internal['format'] = self.config['local_dataset']['data'].lower().split(".")[-1].strip()
        df = self.read_data()
        output_folder = f"{self.output_dir}/{self.config['split_dir']}"
        self.app.internal['splits'] = self.create_splits(df, output_folder)
        return 'WriteResults'

    def read_data(self):
        file_name = self.app.internal['input_files']['data'][0]
        if self.app.internal['format'] == "npy":
            df = self.load_numpy_files(file_name)
        elif self.app.internal['format'] in ["csv", "txt"]:
            df = pd.read_csv(file_name, sep=self.config['local_dataset']['sep'])
        else:
            self.app.log(f"{self.app.internal['format']} file types are not supported", LogLevel.ERROR)
            self.update(state=op_state.ERROR)
        return df

    def load_numpy_files(self, file_name):
        ds = np.load(file_name, allow_pickle=True)
        target_value = self.config['local_dataset'].get('target_value', False)
        if target_value:
            if target_value == 'same-sep':
                return pd.DataFrame({"features": [s for s in ds[0]], "label": ds[1]})
            elif target_value == 'same-last':
                return pd.DataFrame({"features": [s[:-1] for s in ds], "label": [s[-1] for s in ds]})
            elif target_value.strip().split(".")[1].lower() in ['npy', 'npz']:
                labels = np.load(f"{self.input_dir}/{self.config['local_dataset']['target_value']}",
                                 allow_pickle=True)
                return pd.DataFrame({"features": [s for s in ds], "label": labels})
            self.app.log(f"{target_value} is not supported", LogLevel.ERROR)
            self.update(state=op_state.ERROR)
        else:
            self.app.log("For NumPy files, the format of target value should be mentioned through `target_value` "
                     "key in config file", LogLevel.ERROR)
            self.update(state=op_state.ERROR)

    def create_splits(self, data, output_folder):
        os.makedirs(output_folder, exist_ok=True)
        splits = {}
        if self.config['stratify'] and (self.config['local_dataset']['target_value'] is not None):
            self.app.log(f'Use stratified kfold cv for label column', LogLevel.DEBUG)
            cv = StratifiedKFold(n_splits=self.config['n_splits'], shuffle=self.config['shuffle'],
                                 random_state=self.config['random_state'])
            y = data.loc[:, self.config['local_dataset']['target_value']]
            data = data.drop(self.config['local_dataset']['target_value'], axis=1)
            for k, (train_indices, test_indices) in enumerate(cv.split(data, y)):
                path = f'{output_folder}/split_{str(k + 1)}'
                train_df = pd.DataFrame(data.iloc[train_indices], columns=data.columns)
                test_df = pd.DataFrame(data.iloc[test_indices], columns=data.columns)
                splits[path] = [train_df, test_df]
        else:
            self.app.log(f'Use kfold cv', LogLevel.DEBUG)
            cv = KFold(n_splits=self.config['n_splits'], shuffle=self.config['shuffle'],
                       random_state=self.config['random_state'])
            for k, (train_indices, test_indices) in enumerate(cv.split(data)):
                path = f'{output_folder}/split_{str(k + 1)}'
                train_df = pd.DataFrame(data.iloc[train_indices], columns=data.columns)
                test_df = pd.DataFrame(data.iloc[test_indices], columns=data.columns)
                splits[path] = [train_df, test_df]
        return splits


@app_state(name='WriteResults', role=Role.BOTH)
class WriteResults(AppState):
    def register(self):
        pass

    def run(self) -> str or None:
        if self.app.internal['format'] in ["npy", "npz"]:
            for path, [train_df, test_df] in self.app.internal['splits'].items():
                os.mkdir(path)
                np.save(f"{path}/train.npy", [train_df.iloc[:, 0].to_numpy(), train_df.iloc[:, 1].to_numpy()])
                np.save(f"{path}/test.npy", [test_df.iloc[:, 0].to_numpy(), test_df.iloc[:, 1].to_numpy()])
        else:  # csv
            for path, [train_df, test_df] in self.app.internal['splits'].items():
                os.makedirs(path, exist_ok=True)
                train_df.to_csv(f'{path}/train.csv', index=False)
                test_df.to_csv(f'{path}/test.csv', index=False)
        return None
