from FeatureCloud.CustomStates import ConfigState
from FeatureCloud.engine.app import app_state, AppState, Role, LogLevel
from FeatureCloud.engine.app import State as op_state
from FeatureCloud.Utils.utils import log_send_data, log_data
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import bios

name = 'fc_data_distributor'

default_config = {
    name: {
        'local_dataset': {
            'data': 'data.csv',
            'task': 'classification',
            'target_value': '10', # should be str
            'sep': ','
        },
        'sampling': {
            'type': 'Non-IID',
            'non_iid_ness': 1
        },
        'result': {
            'data': 'data.csv'
        }
    }
}

requirements = ['pandas', 'numpy', 'matplotlib', 'seaborn']


@app_state(name='initial', role=Role.BOTH, app_name=name)
class DistributeData(ConfigState.State):

    def register(self):
        self.register_transition('WriteResults', Role.BOTH)

    def run(self):
        self.lazy_init()
        if self.app.coordinator:
            self.read_config()
            self.finalize_config()
            self.sanity_check()
            file_name = self.app.internal['input_files']['data'][0]
            df = self.load_dataset(file_name)
            clients_data = self.sample_dataset(df)

            plot_clients_data(clients_data, self.output_dir)
            config_file = bios.read(self.config_file)
            for client in self.app.clients:
                client_data = clients_data[clients_data.ASSIGNED_CLIENT == client]
                log_send_data([client_data, config_file], self.app.log)
                self.send_data_to_participant(data=[client_data, config_file], destination=client)
            self.app.internal['config'] = self.config
        else:
            self.app.internal['splits'] = {'temp'}

        return 'WriteResults'

    def sanity_check(self):
        self.config['format'] = self.config['local_dataset']['data'].strip().split(".")[-1].lower()
        if not self.config['format'] in ['txt', 'npy', 'csv']:
            # self.log_debug(f"Unsupported {self.config['format']} file extension!", NotImplementedError)
            self.app.log(f"Unsupported {self.config['format']} file extension!", LogLevel.ERROR)
            self.update(state=op_state.ERROR)
        self.config['sampling']['type'] = self.config['sampling']['type'].lower()
        if not self.config['sampling']['type'] in ['non-iid', 'noniid', 'non_iid', 'iid']:
            # self.log_debug(f"Unsupported {self.config['sampling']['type']} type!", NotImplementedError)
            self.app.log(f"Unsupported {self.config['sampling']['type']} type!", LogLevel.ERROR)
            self.update(state=op_state.ERROR)

    def load_dataset(self, file_name):
        """ load dataset with npy(NumPy), txt(text), and csv(supporting different separators) extensions.


        Parameters
        ----------
        file_name: str

        Returns:
        -------
        df: pandas.DataFrame

        """
        if self.config['format'] in ['txt', 'csv']:
            df = pd.read_csv(file_name, sep=self.config['local_dataset']['sep'])
            if self.config['local_dataset']['task'] == "classification":
                df = df.rename(columns={self.config['local_dataset']['target_value']: 'label'})
                self.app.log(df.columns, LogLevel.DEBUG)
                self.app.log(log_dataframe(df), LogLevel.DEBUG)

        elif self.config['format'] in ['npy', 'npz']:
            ds = np.load(file_name, allow_pickle=True)
            self.app.log(f"Number of rows: {len(ds)}\n"
                         f"Number of columns: {len(ds[0])}", LogLevel.DEBUG)
            if self.config['local_dataset']['task'] == 'classification':
                if self.config['local_dataset']['target_value'] == 'same-sep':
                    df = pd.DataFrame({"features": [s for s in ds[0]], "label": ds[1]})
                elif self.config['local_dataset']['target_value'] == 'same-last':
                    df = pd.DataFrame({"features": [s[:-1] for s in ds], "label": [s[-1] for s in ds]})
                elif self.config['local_dataset']['target_value'].strip().split(".")[1].lower() in ['npy', 'npz']:
                    labels = np.load(f"{self.input_dir}/{self.config['local_dataset']['target_value']}",
                                     allow_pickle=True)
                    df = pd.DataFrame({"features": [s for s in ds], "label": labels})
                else:
                    self.app.log(f"Oops! {self.config['local_dataset']['target_value']} is not supported.",
                                 LogLevel.ERROR)
                    self.update(state=op_state.ERROR)
                self.app.log(f"Number of unique labels: {len(df.label.unique())}", LogLevel.DEBUG)
            else:  # Regression or Clustering
                df = pd.DataFrame({"features": [s for s in ds]})

        return df

    def sample_dataset(self, df):
        non_iid_ness = self.config['sampling']['non_iid_ness']
        if self.config['sampling']['type'] in ['non-iid', 'noniid', 'non_iid']:
            labels = df.label.unique()
            if int(non_iid_ness) <= 0 or int(non_iid_ness) > len(labels):
                self.app.log(f"Level of Non-IID-ness is restricted to the number of classes!\n"
                             f"Number of labels: {len(labels)}"
                             f"\nNon-IID-ness: {non_iid_ness}", LogLevel.FATAL)
                self.update(state=op_state.ACTION)
        df['ASSIGNED_CLIENT'] = None
        if self.config['local_dataset']['task'] == 'classification':
            if self.config['sampling']['type'] == 'iid':
                clients_data = supervised_iid_sampling(df, self.app.clients)
            else:
                clients_data = noniid_sampling(df, self.app.clients, non_iid_ness)
        else:
            clients_data = unsupervised_iid_sampling()
        return clients_data


@app_state(name='WriteResults', role=Role.BOTH)
class WriteResults(AppState):
    def register(self):
        self.register_transition('terminal', Role.BOTH)

    def run(self) -> str:
        data, config_file = self.await_data(n=1, unwrap=True, is_json=False)
        if self.app.coordinator:

            file_name = self.app.internal['output_files']['data'][0]
            target = self.app.internal['config']['local_dataset']['target_value']
            format = self.app.internal['config']['format']
            sep = self.app.internal['config']['local_dataset']['sep']
        else:
            log_data(data, self.app.log)
            log_data(config_file, self.app.log)
            output_path = "/mnt/output/"
            file_name = output_path + config_file[name]['result']['data']
            config_filename = output_path + 'config.yml'
            target = config_file[name]['local_dataset']['target_value']
            sep = config_file[name]['local_dataset']['sep']
            format = config_file[name]['local_dataset']['data'].strip().split(".")[-1].lower()
            bios.write(config_filename, config_file)
        if format in ['npy', 'npz']:
            features = data.features.values
            labels = data.label.values
            if target == "same-sep":
                np.save(file_name, np.array([features, labels]))
            elif target == "same-last":
                samples = [np.append(features[i], labels[i]) for i in range(features.shape[0])]
                np.save(file_name, samples)
            elif target.strip().split(".")[1].lower() in ['npy', 'npz']:
                np.save(file_name, data.features.values)
                np.save(target, data.label.values)
            else:
                self.app.log(f"Oops! {target} is not supported.", LogLevel.ERROR)
                self.update(state=op_state.ERROR)
        else:
            data.rename(columns={'label': target}, inplace=True)
            data.to_csv(file_name, sep=sep, index=False)
        return 'terminal'


def supervised_iid_sampling(df, clients):
    """
        IID sampling of data regardless of number of class labels
        Curtrently it supports classification data
         (i.e. each sample should include an arbitrary number of features
            and a single class label from a finite discrete set of lables)

    Parameters
    ----------
    df: pandas.DataFrame
        a dataframe including features and labels of the samples in the dataset
    clients: list
        ID of clients that data should be distributed among them

    Returns
    -------
    clients_data: pandas.DataFrame
        a dataframe including ASSIGNED_CLIENT column to indicate the corresponding client
            that the sample should be assigned.
    """
    labels = df.label.unique()
    clients_data = pd.DataFrame({})
    for label in labels:
        target_label = df[df.label == label]
        proportion = len(target_label) // len(clients)
        for idx, client in enumerate(clients):
            if idx == len(clients) - 1:
                drop_indices = target_label.index.values.tolist()
            else:
                drop_indices = np.random.choice(target_label.index.values.tolist(), proportion, replace=False)
            data = target_label.loc[drop_indices]
            data['ASSIGNED_CLIENT'] = client
            clients_data = clients_data.append(data, ignore_index=True)
            target_label = target_label.drop(drop_indices)
    return clients_data


def flatten(df_lists):
    temp = []
    for df_list in df_lists:
        temp += df_list
    return temp


def noniid_sampling(df, clients, noniid):
    """ NonIID sampling of data to simulate different levels of data heterogeneity
        across clients. An arbitrary number of clients and class labels are supported.
        in case of having less clients than allowed threshold to distribute samples
        of individual classes, the maximum number of available clients will get the samples.

    Parameters
    ----------
    df: pandas.DataFrame
        a dataframe including features and labels of the samples in the dataset
    clients: list
        ID of clients that data should be distributed among them
    noniid: int
        number of clients that have access to samples of an specific class labels.
        In other words, it indicates samples of each class can be found in how many different clients.

    Returns
    -------
    clients_data: pandas.DataFrame
        a dataframe including ASSIGNED_CLIENT column to indicate the corresponding client
            that the sample should be assigned.
    """
    labels = df.label.unique()
    all_splits = [[] for _ in range(noniid)]
    for label in labels:
        target_label = df[df.label == label]
        proportion = len(target_label) // noniid
        for i in range(noniid):
            if i == noniid - 1:
                drop_indices = target_label.index.values.tolist()
            else:
                drop_indices = np.random.choice(target_label.index.values.tolist(), proportion, replace=False)
            data = target_label.loc[drop_indices]
            all_splits[i].append(data)
            target_label = target_label.drop(drop_indices)
    splits = flatten(all_splits)
    clients_data = pd.DataFrame([], columns=df.columns)
    counter = 0
    n_labels_for_assign = len(labels) * noniid // len(clients)
    extras = len(labels) * noniid % len(clients)
    for client in clients:
        for _ in range(n_labels_for_assign):
            data = splits[counter]
            data['ASSIGNED_CLIENT'] = client
            clients_data = clients_data.append(data, ignore_index=True)
            counter += 1
        if extras > 0:
            data = splits[counter]
            data['ASSIGNED_CLIENT'] = client
            clients_data = clients_data.append(data, ignore_index=True)
            counter += 1
            extras -= 1
    return clients_data


def plot_clients_data(df, path):
    """

    Parameters
    ----------
    df: pandas.DataFrame
    path: str

    """
    ax = sns.countplot(data=df, hue='label', x='ASSIGNED_CLIENT')
    ax.legend(bbox_to_anchor=(0.99, 1.05))
    for v in df.ASSIGNED_CLIENT.unique()[:-1]:
        plt.axvline(x=v, color='black', linestyle='dotted')
    plt.savefig(f'{path}/hist.png')


def unsupervised_iid_sampling():
    raise NotImplementedError


def log_dataframe(df):
    msg = f"Pandas DataFrame: \n" \
          f"Number of rows: {len(df)}\n" \
          f"Number of Columns: {len(df.columns)} \n"
    if len(df.columns.values) > 8:
        for c in df.columns.values[:5]:
            msg += f"\t{c}\n"
        msg += "\t.\n\t.\n\t.\n"
        for c in df.columns.values[-3:]:
            msg += f"\t{c}\n"
    else:
        for c in df.columns.values[:5]:
            msg += f"\t{c}\n"
    return msg
