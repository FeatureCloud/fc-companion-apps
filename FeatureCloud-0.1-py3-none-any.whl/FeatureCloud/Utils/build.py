import os
import tempfile
import shutil

import bios


def get_nginx():
    """ Gets NginX cinfigs

    Returns
    -------
    str:
    """
    nginx = "server {\n" \
            "\tlisten 9000;\n" \
            "\tlisten [::]:9000;\n" \
            "\tclient_max_body_size 0;\n\n" \
            "\tlocation / {\n" \
            "\t\tinclude proxy_params;\n" \
            "\t\tproxy_pass http://127.0.0.1:5000/api/;\n" \
            "\t}\n" \
            "}\n\n" \
            "server {\n" \
            "\tlisten 9001;\n" \
            "\tlisten [::]:9001;\n" \
            "\tclient_max_body_size 0;\n\n" \
            "\tlocation /static {\n" \
            "\t\talias /app/fc_app/static/;\n" \
            "\t}\n\n" \
            "\tlocation / {\n" \
            "\t\tinclude proxy_params;\n" \
            "\t\tproxy_pass http://127.0.0.1:5000/web/;\n" \
            "\t}\n" \
            "}"
    return nginx


def get_supervisord():
    """ Returns Supervisord configs

    Returns
    -------
    str:
    """
    supervisord = "[supervisord]\n" \
                  "nodaemon=true\n\n" \
                  "[program:nginx]\n" \
                  "command=/usr/sbin/nginx -g 'daemon off;'\n" \
                  "autostart=true\n" \
                  "autorestart=true\n" \
                  "stdout_logfile=/dev/fd/1\n" \
                  "stdout_logfile_maxbytes=0\n" \
                  "stderr_logfile=/dev/stderr\n" \
                  "stderr_logfile_maxbytes=0\n\n" \
                  "[program:app]\n" \
                  "command=/usr/local/bin/python3 -u /app/main.py\n" \
                  "autostart=true\n" \
                  "autorestart=true\n" \
                  "stdout_logfile=/dev/stdout\n" \
                  "stdout_logfile_maxbytes=0\n" \
                  "stderr_logfile=/dev/stderr\n" \
                  "stderr_logfile_maxbytes=0"
    return supervisord


def build_configs(docker_img_name, working_dir=os.getcwd()):
    """ Creat config files, app requirements, build, and Dockerfile
        in the directory.
        After calling this method the image is ready to be used.
        this function uses default FeatureCloud Requirements.

    Parameters
    ----------
    docker_img_name: str
    working_dir: str
        path to dir that files should be stored

    """

    if os.getcwd() != working_dir:
        if not os.path.isdir(working_dir):
            raise NotADirectoryError(f"{working_dir} dose not exist!")

    # Creating Server Config
    server_conf_dir = f"{working_dir}/.server_config"
    os.mkdir(server_conf_dir)

    # Create entrypoint.sh

    create_file(file_name=f"{server_conf_dir}/docker-entrypoint.sh",
                content="/usr/bin/supervisord -c '/supervisord.conf'")

    create_file(file_name=f"{server_conf_dir}/nginx", content=get_nginx())
    create_file(file_name=f"{server_conf_dir}/supervisord.conf", content=get_supervisord())

    # create Dockerfile & build.sh
    create_docker_file(filename=f"{server_conf_dir}/Dockerfile")
    create_build_sh(filename=f"{server_conf_dir}/build.sh", app_name=docker_img_name)


def create_requirements(requirements=None, working_dir=os.getcwd(), overwrite=False):
    """ Creat requirements.txt file for the app
        All received apps will be combined with the default FeatureCloud requirements

    Parameters
    ----------
    requirements: list
        list of required libraries to be installed
    working_dir: str
        path to where requirements.txt file should be stored
    overwrite: bool
        if True: once the file already exist, it will be overwritten

    """
    if not os.path.isdir(working_dir):
        raise NotADirectoryError(f"{working_dir} is not a directory")
    if not overwrite:
        if os.path.isfile(f"{working_dir}/requirements.txt"):
            raise FileExistsError(f"{working_dir}/requirements.txt already exist")

    if requirements is None:
        print("Requirements are not provided!\n"
              "By default general FeatureCloud requirements will be installed")

    for r in list_requirements():
        if r not in requirements:
            requirements.append(r)

    req = ""
    for r in requirements:
        req += r + "\n"

    create_file(file_name=f"{working_dir}/requirements.txt", content=req)


def build_docker_image_on_fly(app_name, requirements):
    """ Creates Docker image without remaining any files ro directories behind
        Creats all config files + Dockerfile
        And call `docker build` to build teh container
        Finally, removes all the created files.

    Parameters
    ----------
    app_name: str
        docker image name
    requirements: str

    """
    # Creating Server Config
    server_conf_dir = "./server_config"
    if not os.path.isdir(server_conf_dir):
        os.mkdir(server_conf_dir)

    create_requirements(requirements, server_conf_dir)
    # create_requirements(requirements, "./")

    # Create entrypoint.sh

    create_file(file_name=f"{server_conf_dir}/docker-entrypoint.sh",
                content="/usr/bin/supervisord -c '/supervisord.conf'")

    create_file(file_name=f"{server_conf_dir}/nginx", content=get_nginx())
    create_file(file_name=f"{server_conf_dir}/supervisord.conf", content=get_supervisord())

    # create Dockerfile & build.sh
    create_docker_file(filename=f"{os.getcwd()}/Dockerfile", work_dir=server_conf_dir)
    os.system(f'docker build . --tag featurecloud.ai/{app_name}')

    # remove created files
    os.remove("Dockerfile")
    shutil.rmtree(server_conf_dir)


def run(host='localhost', port=5000):
    """ run the docker container on specific host and port.

    Parameters
    ----------
    host: str
    port: int

    """
    from FeatureCloud.api.http_ctrl import api_server
    from FeatureCloud.api.http_web import web_server
    from bottle import Bottle
    from FeatureCloud.engine.app import app
    app.register()
    server = Bottle()
    server.mount('/api', api_server)
    server.mount('/web', web_server)
    server.run(host=host, port=port)


def list_requirements():
    """ Returns FeatureCloud requirements

    Returns
    -------
    list: list of general requirements
    """
    req = ["bottle", "jsonpickle", "joblib", "bios", "pydot", "pyyaml", "./FeatureCloud-0.1-py3-none-any.whl"]
    return req


def create_docker_file(filename, work_dir):
    """ Creat Dockerfile for a FeatureCloud app

    Parameters
    ----------
    filename: str
        docker image filename
    work_dir: str

    """
    # create dockerfile
    docker_file = "FROM python:3.8-buster\n\n" \
                  "RUN apt-get update && apt-get install -y supervisor nginx\n\n" \
                  "RUN pip3 install --upgrade pip\n\n" \
                  f"COPY {work_dir}/supervisord.conf /supervisord.conf\n" \
                  f"COPY {work_dir}/nginx /etc/nginx/sites-available/default\n" \
                  f"COPY {work_dir}/docker-entrypoint.sh /entrypoint.sh\n\n" \
                  f"COPY {work_dir}/requirements.txt /app/requirements.txt\n" \
                  f"COPY FeatureCloud-0.1-py3-none-any.whl /FeatureCloud-0.1-py3-none-any.whl\n" \
                  f"RUN pip3 install -r ./app/requirements.txt\n\n" \
                  "COPY . /app\n\n" \
                  "EXPOSE 9000 9001\n\n" \
                  "ENTRYPOINT ['sh', '/entrypoint.sh']"
    create_file(filename, docker_file.replace("'", '"'))


# def create_docker_file_without_creating_files(filename, requirements):
#     # create dockerfile
#
#     docker_file = "FROM python:3.8-buster\n\n" \
#                   "RUN apt-get update && apt-get install -y supervisor nginx\n\n" \
#                   "RUN pip3 install --upgrade pip\n\n" \
#                   f"RUN  '{get_supervisord()}' >> supervisord.conf\n" \
#                   f"RUN {get_nginx()} >> /etc/nginx/sites-available/default/nginx\n" \
#                   f"RUN /usr/bin/supervisord -c '/supervisord.conf' >> /entrypoint.sh\n\n" \
#                   f"RUN {requirements} >> /app/requirements.txt\n" \
#                   "RUN pip3 install -r ./app/requirements.txt\n\n" \
#                   "COPY . /app\n\n" \
#                   "EXPOSE 9000 9001\n\n" \
#                   "ENTRYPOINT ['sh', '/entrypoint.sh']"
#     create_file(filename, content=docker_file)


def create_build_sh(filename, app_name):
    build_sh = f"#!/bin/bash\n\n" \
               f"docker build . --tag featurecloud.ai/{app_name}"
    create_file(filename, build_sh)


def create_file(file_name, content):
    f = open(file_name, 'w')
    f.write(content)
    f.close()


def create_config(config):
    bios.write(config)
